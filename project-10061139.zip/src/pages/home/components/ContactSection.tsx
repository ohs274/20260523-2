import { useState } from 'react';

const formSubmitUrl = 'https://readdy.ai/api/form/d8800fdf07jn52r5qof0';

export default function ContactSection() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: '',
  });
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors?.[name]) {
      setErrors((prev) => {
        const next = { ...prev };
        delete next[name];
        return next;
      });
    }
  };

  const validate = () => {
    const nextErrors: Record<string, string> = {};
    if (!formData.name.trim()) nextErrors.name = '名前を入力してください';
    if (!formData.email.trim()) {
      nextErrors.email = 'メールアドレスを入力してください';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      nextErrors.email = '正しいメールアドレスを入力してください';
    }
    if (!formData.message.trim()) nextErrors.message = '問い合わせ内容を入力してください';
    return nextErrors;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const nextErrors = validate();
    if (Object.keys(nextErrors).length > 0) {
      setErrors(nextErrors);
      return;
    }

    const params = new URLSearchParams();
    params.append('name', formData.name);
    params.append('email', formData.email);
    if (formData.phone) params.append('phone', formData.phone);
    params.append('message', formData.message);

    fetch(formSubmitUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: params.toString(),
    })
      .then(() => setSubmitted(true))
      .catch(() => setErrors({ message: '送信に失敗しました。時間をおいて再度お試しください。' }));
  };

  return (
    <section id="contact" className="py-16 md:py-24 bg-[#F5F5F0]">
      <div className="w-full px-4 md:px-8 lg:px-12">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 md:gap-16">
            <div>
              <p className="text-xs md:text-sm font-semibold text-gray-400 tracking-[0.2em] uppercase mb-2">
                Contact Us
              </p>
              <h2 className="text-2xl md:text-4xl font-bold text-gray-900 mb-4">
                お問い合わせ
              </h2>
              <p className="text-sm md:text-base text-gray-600 leading-relaxed mb-8">
                鉄骨金物に関するご相談・お見積もり・資料請求など、お気軽にお問い合わせください。
                専門スタッフが迅速にご対応いたします。
              </p>

              <div className="space-y-5">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 flex items-center justify-center bg-gray-900 rounded-full shrink-0">
                    <i className="ri-phone-line text-white" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-gray-900 mb-1">お電話でのお問い合わせ</p>
                    <a href="tel:072-349-1535" className="text-base md:text-lg font-bold text-gray-900 hover:underline">
                      072-349-1535
                    </a>
                    <p className="text-xs text-gray-500 mt-1">受付時間：平日 9:00～17:00</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 flex items-center justify-center bg-gray-900 rounded-full shrink-0">
                    <i className="ri-mail-line text-white" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-gray-900 mb-1">メールでのお問い合わせ</p>
                    <a href="mailto:info@daiko-sangyo.example" className="text-base md:text-lg font-bold text-gray-900 hover:underline">
                      info@daiko-sangyo.example
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 flex items-center justify-center bg-gray-900 rounded-full shrink-0">
                    <i className="ri-map-pin-line text-white" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-gray-900 mb-1">所在地</p>
                    <p className="text-base text-gray-700">
                      〒580-0006
                      <br />
                      大阪府松原市大堀5-3-3
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl p-6 md:p-8">
              {submitted ? (
                <div className="text-center py-10">
                  <div className="w-16 h-16 mx-auto flex items-center justify-center bg-green-100 rounded-full mb-4">
                    <i className="ri-check-line text-3xl text-green-600" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">
                    お問い合わせありがとうございます
                  </h3>
                  <p className="text-sm text-gray-600">
                    内容を確認の上、担当者よりご連絡いたします。
                  </p>
                </div>
              ) : (
                <form
                  id="contact-form"
                  data-readdy-form
                  action={formSubmitUrl}
                  method="POST"
                  onSubmit={handleSubmit}
                >
                  <div className="space-y-5">
                    <div>
                      <label htmlFor="name" className="block text-sm font-semibold text-gray-700 mb-1.5">
                        お名前 <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        className={`w-full px-4 py-3 text-sm border rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-900 ${
                          errors.name ? 'border-red-400' : 'border-gray-200'
                        }`}
                        placeholder="山田 太郎"
                      />
                      {errors.name && (
                        <p className="mt-1 text-xs text-red-500">{errors.name}</p>
                      )}
                    </div>

                    <div>
                      <label htmlFor="email" className="block text-sm font-semibold text-gray-700 mb-1.5">
                        メールアドレス <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        className={`w-full px-4 py-3 text-sm border rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-900 ${
                          errors.email ? 'border-red-400' : 'border-gray-200'
                        }`}
                        placeholder="example@email.com"
                      />
                      {errors.email && (
                        <p className="mt-1 text-xs text-red-500">{errors.email}</p>
                      )}
                    </div>

                    <div>
                      <label htmlFor="phone" className="block text-sm font-semibold text-gray-700 mb-1.5">
                        電話番号
                      </label>
                      <input
                        type="tel"
                        id="phone"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        className="w-full px-4 py-3 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-900"
                        placeholder="072-349-1535"
                      />
                    </div>

                    <div>
                      <label htmlFor="message" className="block text-sm font-semibold text-gray-700 mb-1.5">
                        問い合わせ内容 <span className="text-red-500">*</span>
                      </label>
                      <textarea
                        id="message"
                        name="message"
                        value={formData.message}
                        onChange={handleChange}
                        rows={5}
                        maxLength={500}
                        className={`w-full px-4 py-3 text-sm border rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-900 resize-none ${
                          errors.message ? 'border-red-400' : 'border-gray-200'
                        }`}
                        placeholder="お問い合わせ内容をご記入ください（500文字以内）"
                      />
                      <div className="flex justify-between mt-1">
                        {errors.message && (
                          <p className="text-xs text-red-500">{errors.message}</p>
                        )}
                        <p className="text-xs text-gray-400 ml-auto">
                          {formData.message.length}/500
                        </p>
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="w-full inline-flex items-center justify-center px-8 py-3.5 text-base font-semibold text-white bg-gray-900 rounded-full hover:bg-gray-800 transition-colors whitespace-nowrap"
                    >
                      送信する
                      <i className="ri-send-plane-line ml-2" />
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}