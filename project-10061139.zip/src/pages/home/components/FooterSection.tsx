const footerLinks = [
  { label: '会社概要', href: '#about' },
  { label: '事業内容', href: '#services' },
  { label: '強み・実績', href: '#strength' },
  { label: 'お問い合わせ', href: '#contact' },
];

export default function FooterSection() {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="w-full px-4 md:px-8 lg:px-12 py-12 md:py-16">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10 md:gap-12 mb-10 md:mb-12">
            <div>
              <h3 className="text-xl md:text-2xl font-bold mb-4">大幸産業</h3>
              <p className="text-sm text-gray-400 leading-relaxed">
                建設現場を支える、確かな鉄骨金物の力。
                <br />
                品質と納期に徹底してこだわり、
                <br />
                お客様の信頼に応えます。
              </p>
            </div>

            <div>
              <h4 className="text-sm font-semibold text-white mb-4 tracking-wide">
                サイトマップ
              </h4>
              <ul className="space-y-3">
                {footerLinks.map((link) => (
                  <li key={link.href}>
                    <a
                      href={link.href}
                      className="text-sm text-gray-400 hover:text-white transition-colors"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h4 className="text-sm font-semibold text-white mb-4 tracking-wide">
                会社情報
              </h4>
              <ul className="space-y-3 text-sm text-gray-400">
                <li>〒580-0006</li>
                <li>大阪府松原市大堀5-3-3</li>
                <li>
                  TEL：
                  <a href="tel:072-349-1535" className="hover:text-white transition-colors">
                    072-349-1535
                  </a>
                </li>
                <li>
                  メール：
                  <a
                    href="mailto:info@daiko-sangyo.example"
                    className="hover:text-white transition-colors"
                  >
                    info@daiko-sangyo.example
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 pt-6 md:pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-xs text-gray-500">
              © {new Date().getFullYear()} 大幸産業 All Rights Reserved.
            </p>
            <p className="text-xs text-gray-600">DAIKO SANGYO CO., LTD.</p>
          </div>
        </div>
      </div>
    </footer>
  );
}