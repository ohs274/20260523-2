import { heroImage } from '@/mocks/homeImages';

export default function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0">
        <img
          src={heroImage}
          alt="建設現場の鉄骨構造"
          className="w-full h-full object-cover object-top"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/40 to-black/60" />
      </div>

      <div className="relative z-10 w-full px-4 md:px-8 lg:px-12 text-center">
        <p className="text-xs md:text-sm font-medium text-white/80 tracking-[0.2em] uppercase mb-4 md:mb-6">
          Steel Hardware Manufacturer
        </p>
        <h1 className="text-3xl md:text-5xl lg:text-6xl font-bold text-white leading-tight mb-6 md:mb-8">
          建設現場を支える、
          <br className="hidden sm:block" />
          確かな鉄骨金物の力
        </h1>
        <p className="text-base md:text-lg text-white/90 max-w-2xl mx-auto mb-8 md:mb-10 leading-relaxed">
          大阪府松原市に拠点を置く大幸産業は、
          <br className="hidden sm:block" />
          建築現場で使用される高品質な鉄骨金物の製造・販売を手掛けています。
          <br className="hidden sm:block" />
          品質と納期に徹底してこだわり、お客様の信頼に応えます。
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <a
            href="#services"
            className="inline-flex items-center px-8 py-3.5 text-base font-semibold text-white border-2 border-white/80 rounded-full hover:bg-white/10 transition-colors whitespace-nowrap"
          >
            事業内容を見る
            <i className="ri-arrow-right-line ml-2" />
          </a>
        </div>
      </div>

      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 animate-bounce">
        <i className="ri-arrow-down-line text-2xl text-white/70" />
      </div>
    </section>
  );
}