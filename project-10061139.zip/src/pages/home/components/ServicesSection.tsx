import { serviceImage1, serviceImage2, serviceImage3 } from '@/mocks/homeImages';

const services = [
  {
    image: serviceImage1,
    tag: '製造',
    title: '鉄骨金物製造',
    description:
      '建築現場で使用される各種鉄骨金物を自社工場で一貫製造。部材加工から溶接・仕上げまで、熟練の職人技と最新設備を融合し、高精度な製品をお届けします。',
  },
  {
    image: serviceImage2,
    tag: '品質管理',
    title: '品質検査・管理',
    description:
      'JIS規格に準拠した徹底した品質管理システムを導入。出荷前の全数検査から材料のトレーサビリティまで、安全性と信頼性を第一に考えた品質保証体制を構築しています。',
  },
  {
    image: serviceImage3,
    tag: '配送・施工対応',
    title: '現場配送・施工サポート',
    description:
      '全国の建設現場へタイムリーな配送を実現。お客様の工程に合わせた納期調整から、現場での施工上のご相談まで、緻密なサポート体制で建設プロジェクトを支えます。',
  },
];

export default function ServicesSection() {
  return (
    <section id="services" className="py-16 md:py-24 bg-white">
      <div className="w-full px-4 md:px-8 lg:px-12">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4 mb-10 md:mb-14">
            <div>
              <p className="text-xs md:text-sm font-semibold text-gray-400 tracking-[0.2em] uppercase mb-2">
                Products & Services
              </p>
              <h2 className="text-2xl md:text-4xl font-bold text-gray-900">
                事業内容・製品サービス
              </h2>
            </div>
            <p className="text-sm md:text-base text-gray-600 max-w-md leading-relaxed">
              建設現場のニーズに寄り添い、鉄骨金物の製造から配送・施工サポートまでトータルソリューションを提供します。
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
            {services.map((service, index) => (
              <div
                key={index}
                className="group bg-white rounded-xl overflow-hidden border border-gray-100 hover:shadow-lg transition-shadow"
              >
                <div className="aspect-[4/3] overflow-hidden">
                  <img
                    src={service.image}
                    alt={service.title}
                    className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-500"
                  />
                </div>
                <div className="p-5 md:p-6">
                  <span className="inline-block px-3 py-1 text-xs font-semibold bg-[#C8D600] text-gray-900 rounded-full mb-3">
                    {service.tag}
                  </span>
                  <h3 className="text-lg md:text-xl font-bold text-gray-900 mb-2">
                    {service.title}
                  </h3>
                  <p className="text-sm md:text-base text-gray-600 leading-relaxed">
                    {service.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}