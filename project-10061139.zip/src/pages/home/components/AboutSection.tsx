import { aboutImage } from '@/mocks/homeImages';

const companyInfo = [
  { label: '会社名', value: '大幸産業' },
  { label: '所在地', value: '〒580-0006 大阪府松原市大堀5-3-3' },
  { label: '代表者名', value: '代表取締役　河野賢二' },
  { label: '創業年', value: '2001年5月（平成13年5月）' },
  { label: '事業内容', value: '鉄骨金物の製造・販売' },
];

export default function AboutSection() {
  return (
    <section id="about" className="py-16 md:py-24 bg-[#F5F5F0]">
      <div className="w-full px-4 md:px-8 lg:px-12">
        <div className="max-w-6xl mx-auto">
          <p className="text-xs md:text-sm font-semibold text-gray-500 tracking-[0.2em] uppercase mb-3">
            About Us
          </p>
          <h2 className="text-2xl md:text-4xl font-bold text-gray-900 mb-10 md:mb-14">
            大幸産業
          </h2>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-12 items-start">
            <div className="space-y-6">
              <p className="text-base md:text-lg text-gray-700 leading-relaxed">
                2001年（平成13年）の創業以来、建築現場で使用される鉄骨金物の製造・販売を通じて、
                日本の建設業界を支えてまいりました。
                品質管理と短納期対応を強みに、お客様の多様なニーズにお応えしています。
              </p>

              <div className="bg-white rounded-xl p-6 md:p-8 space-y-4">
                {companyInfo.map((item) => (
                  <div
                    key={item.label}
                    className="flex flex-col sm:flex-row sm:items-start gap-1 sm:gap-4"
                  >
                    <span className="text-sm font-semibold text-gray-500 sm:w-28 shrink-0">
                      {item.label}
                    </span>
                    <span className="text-base text-gray-900">{item.value}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-6">
              <div className="rounded-xl overflow-hidden">
                <img
                  src={aboutImage}
                  alt="大幸産業 工場"
                  className="w-full h-64 md:h-80 object-cover object-top"
                />
              </div>

              <div className="rounded-xl overflow-hidden bg-white">
                <iframe
                  src="https://maps.google.com/maps?q=34.5891684,135.5777755&z=19&hl=ja&ie=UTF8&iwloc=B&output=embed"
                  width="100%"
                  height="280"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="大幸産業 所在地"
                  className="w-full"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}