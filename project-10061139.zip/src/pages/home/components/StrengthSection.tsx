const strengths = [
  {
    icon: 'ri-shield-check-line',
    number: '25年',
    label: '創業以来の実績',
    description: '2001年（平成13年）創業以来、鉄骨金物製造のノウハウと信頼を積み重ねてきました。',
  },
  {
    icon: 'ri-flashlight-line',
    number: '3,000t',
    label: '年間生産能力',
    description: '最新鋭の製造設備と効率的な生産ラインで、年間3,000トンの製造能力を持ちます。',
  },
  {
    icon: 'ri-map-2-line',
    number: '45',
    label: '対応都道府県数',
    description: '全国45都道府県への配送実績があり、現場のニーズに即応する物流ネットワークを構築しています。',
  },
];

const stats = [
  { value: '25+', label: '年の実績' },
  { value: '3,000', label: 't/年生産' },
  { value: '45', label: '都道府県対応' },
  { value: '99.8%', label: '納期遵守率' },
];

export default function StrengthSection() {
  return (
    <section id="strength" className="py-16 md:py-24 bg-gray-50">
      <div className="w-full px-4 md:px-8 lg:px-12">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-10 md:mb-14">
            <p className="text-xs md:text-sm font-semibold text-gray-400 tracking-[0.2em] uppercase mb-2">
              Strength & Achievements
            </p>
            <h2 className="text-2xl md:text-4xl font-bold text-gray-900 mb-4">
              強み・実績
            </h2>
            <p className="text-sm md:text-base text-gray-600 max-w-2xl mx-auto">
              大幸産業は創業以来、品質・納期・対応力の三つの軸でお客様の信頼を築いてきました。
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8 mb-14 md:mb-20">
            {strengths.map((item, index) => (
              <div
                key={index}
                className="bg-white rounded-xl p-6 md:p-8 text-center hover:shadow-md transition-shadow"
              >
                <div className="w-14 h-14 md:w-16 md:h-16 mx-auto flex items-center justify-center bg-[#C8D600]/10 rounded-full mb-5">
                  <i className={`${item.icon} text-2xl md:text-3xl text-[#8B9A00]`} />
                </div>
                <h3 className="text-xl md:text-2xl font-bold text-gray-900 mb-2">
                  {item.number}
                </h3>
                <p className="text-sm font-semibold text-gray-500 mb-3">
                  {item.label}
                </p>
                <p className="text-sm md:text-base text-gray-600 leading-relaxed">
                  {item.description}
                </p>
              </div>
            ))}
          </div>

          <div className="bg-gray-900 rounded-xl p-6 md:p-10">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
              {stats.map((stat, index) => (
                <div key={index} className="text-center">
                  <p className="text-2xl md:text-4xl font-bold text-white mb-1">
                    {stat.value}
                  </p>
                  <p className="text-xs md:text-sm text-gray-400">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}