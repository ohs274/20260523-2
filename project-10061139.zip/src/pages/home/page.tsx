import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import AboutSection from './components/AboutSection';
import ServicesSection from './components/ServicesSection';
import StrengthSection from './components/StrengthSection';
import ContactSection from './components/ContactSection';
import FooterSection from './components/FooterSection';

export default function Home() {
  return (
    <main className="min-h-screen bg-white">
      <Navbar />
      <HeroSection />
      <AboutSection />
      <ServicesSection />
      <StrengthSection />
      <ContactSection />
      <FooterSection />
    </main>
  );
}